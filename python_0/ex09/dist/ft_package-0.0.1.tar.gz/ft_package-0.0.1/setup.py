from setuptools import setup, find_packages

setup(
    name="ft_package",
    version="0.0.1",
    summary="A sample test package",
    packages=find_packages(),
    license="MIT",
    author="jdenis",
    author_email="jdenis@student.42.com",
    install_requires=[],
)
